module.exports ={
    berita(req,res){
        res.render("berita",{
            url: 'http://localhost:5050/'
             });
        }
    }
