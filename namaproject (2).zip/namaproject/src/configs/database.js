module.exports = {
    multipleStatements  : true,
    host                : 'localhost',
    user                : 'root',
    password            : '',
    database            : 'db_express_mysql'
};